import tkinter as tk
import webbrowser

def rickroll():
    # URL of the Rick Astley's "Never Gonna Give You Up" video
    url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
    webbrowser.open(url)

# Initialize Tkinter window
window = tk.Tk()
window.title("Click the button!")

# Create a label
label = tk.Label(window, text="Don't click the button below for a free prize!")
label.pack(pady=10)

# Create a button that triggers the rickroll function
button = tk.Button(window, text="Click me!", command=rickroll)
button.pack(pady=10)

# Start the Tkinter event loop
window.mainloop()
