import tkinter as tk
import requests
import random
# Function to send message to Discord webhook
def send_webhook(url, content):
    payload = {"content": content}
    requests.post(url, json=payload)

# Function to handle user guess
def handle_guess():
    global guess_count, secret_number, webhook_url

    user_guess = int(guess_entry.get())
    guess_count += 1

    if user_guess == secret_number:
        message = f"Congratulations! You've guessed the number {secret_number} correctly in {guess_count} guesses!"
        send_webhook(webhook_url, message)
        result_label.config(text=message)
        guess_entry.config(state=tk.DISABLED)
        guess_button.config(state=tk.DISABLED)
    elif user_guess < secret_number:
        send_webhook(webhook_url, "Too low! Try guessing a higher number.")
        result_label.config(text="Too low! Try guessing a higher number.")
    else:
        send_webhook(webhook_url, "Too high! Try guessing a lower number.")
        result_label.config(text="Too high! Try guessing a lower number.")

# Initialize Tkinter window
window = tk.Tk()
window.title("Guess the Number Game")

# Replace 'YOUR_WEBHOOK_URL' with your actual Discord webhook URL
webhook_url = " https://discord.com/api/webhooks/1251303944039432252/TFS_-Q_9Y49ppuwJ2i0k1i4GKUu7HGfh_xaDD5JNaVmotc7W9to6puJFy4PFismmyO64"

# Send initial game instructions to the Discord webhook
send_webhook(webhook_url, "Welcome to Guess the Number game! I'm thinking of a number between 1 and 100. Can you guess it?")

# Generate a random number between 1 and 100
secret_number = random.randint(1, 100)

# GUI components
instruction_label = tk.Label(window, text="Enter your guess (between 1 and 100):")
instruction_label.pack(pady=10)

guess_entry = tk.Entry(window, width=20)
guess_entry.pack(pady=5)

guess_button = tk.Button(window, text="Guess", command=handle_guess)
guess_button.pack(pady=10)

result_label = tk.Label(window, text="")
result_label.pack(pady=10)

# Track guess count
guess_count = 0

# Start Tkinter event loop
window.mainloop()